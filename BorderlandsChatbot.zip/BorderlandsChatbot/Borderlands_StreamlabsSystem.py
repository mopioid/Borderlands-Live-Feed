import os
import sys
import re
import json
import ctypes
import codecs

ScriptName = "Borderlands"
Website = "https://www.twitch.tv/mopioid"
Description = "Provides live BL2 & TPS data in response to !build & !level."
Creator = "mopioid"
Version = "1.1"


# The path to the directory containing this script and its resources.
ScriptDir = os.path.dirname(os.path.realpath(__file__))
# The path to the helper program within our directory, formatted for popen.
HelperCommand = '"' + os.path.join(ScriptDir, 'ChatbotHelper.exe') + '"'

# Loads a JSON file from our directory in the proper encoding.
def LoadFile(path):
	with codecs.open(path, encoding='utf-8-sig', mode='r') as file:
		return json.load(file, encoding='utf-8-sig')

# Load our UI configuration file.
UIConfig = LoadFile(os.path.join(ScriptDir, 'UI_Config.json'))
# From our UI configuration, retrieve the name of our settings file.
SettingsPath = os.path.join(ScriptDir, UIConfig["output_file"])


# Executed by Chatbot when the script is imported/reloaded.
def Init():
	# Store the display name for the broadcaster.
	global Broadcaster
	Broadcaster = Parent.GetDisplayName(Parent.GetChannelName())
	# Load our settings.
	LoadSettings()

# Executed by Chatbot when the user saves our settings in the UI.
def ReloadSettings(data):
	# Load our settings.
	LoadSettings()

# Load our settings.
def LoadSettings():
	global Settings
	try:
		# Attempt to determine our settings by reading our settings file.
		Settings = LoadFile(SettingsPath)
	except:
		# If reading our settings file failed, iterate over our UI configuration
		# file to locate the default values.
		Settings = {}
		for key, value in UIConfig.iteritems():
			try:
				# If an entry in the configuration file is a dictionary that
				# contains the 'value' key, that value is the default for the
				# setting associated with that key.
				Settings[key] = value['value']
			except:
				pass

def Tick():
	return

def Execute(data):
	# If this is not a Twitch chat message, ignore it.
	if not data.IsChatMessage() or not data.IsFromTwitch():
		return

	# The command to try is the first parameter in the message, in lowercase.
	command = data.GetParam(0).lower()
	try:
		# If the first character is not a '!', or if we have an entry for it
		# in our settings but its value is False, stop here.
		if command[0] != '!' or Settings[command] != True:
			return
	except:
		# If locating the command in our settings failed, stop here.
		return

	# If we are using cooldown, perform management of it now.
	if Settings['cooldown'] > 0:
		# If the command is currently on cooldown, stop here.
		if Parent.IsOnCooldown(ScriptName, command):
			return
		# Otherwise, set it to be on cooldown now.
		Parent.AddCooldown(ScriptName, command, Settings['cooldown'])

	# Perform the command, and reply in Twitch chat with its results.
	Parent.SendTwitchMessage(PerformCommand(command))

def PerformCommand(command):
	# Join the path to the helper program, the specified command, and the name
	# of the broadcaster into a single command line command.
	command = '%s %s %s' % (HelperCommand, command, Broadcaster)
	# We will be seeking for output until we find a non-empty string.
	output = ""
	# Invoke the command, opening the file from which we can read its output.
	with os.popen(command, 'r') as outputFile:
		# So long as no output has been found yet, attempt a read from the file. 
		while output == "":
			output = outputFile.readline()
	# Once output has been found, return it.
	return output

# Broadcaster = 'mopioid'
# print PerformCommand('!build')
# print PerformCommand('!level')

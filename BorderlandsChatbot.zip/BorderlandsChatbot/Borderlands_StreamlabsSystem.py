import os
import sys
import codecs
import json
import time


ScriptName = "Borderlands"
Website = "https://www.twitch.tv/mopioid"
Description = "Provides live BL2 & TPS data in response to !build & !level."
Creator = "mopioid"
Version = "1.2"


# Loads a JSON file from our directory in the proper encoding.
def LoadFile(path):
	with codecs.open(path, encoding='utf-8-sig', mode='r') as file:
		return json.load(file, encoding='utf-8-sig')


# Executed by Chatbot when the script is imported/reloaded.
def Init():
	# Store the display name for the broadcaster.
	global Broadcaster
	try:
		Broadcaster = Parent.GetDisplayName(Parent.GetChannelName())
	# If the Parent object is not defined, we are being run outside of Chatbot,
	# (i.e. testing), so use a placeholder value.
	except:
		Broadcaster = '[Broadcaster]'

	# The path to the directory containing this script and its resources.
	scriptDir = os.path.dirname(os.path.realpath(__file__))

	# The path to the helper program within our directory, formatted for popen.
	global HelperCommand
	HelperCommand = '"' + os.path.join(scriptDir, 'ChatbotHelper.exe') + '"'

	# Load our UI configuration file.
	config = LoadFile(os.path.join(scriptDir, 'UI_Config.json'))

	# From our UI configuration, retrieve the name of our settings file.
	global SettingsPath
	SettingsPath = os.path.join(scriptDir, config["output_file"])

	# Iterate over our UI configuration file to locate the default settings.
	global Settings
	Settings = {}
	for key, value in config.iteritems():
		try:
			# If an entry in the configuration file is a dictionary containing
			# the 'value' key, that value is the default for that key's setting.
			Settings[key] = value['value']
		except:
			pass

	# Load the user's settings.
	ReloadSettings(None)


# Executed by Chatbot when the user saves our settings in the UI.
def ReloadSettings(data):
	try:
		# Attempt to determine the user's settings by reading our settings file.
		for key, value in LoadFile(SettingsPath):
			# Apply each setting that exists in the file to our settings.
			Settings[key] = value
	except:
		pass


def Tick():
	return


def Execute(data):
	# If this is not a Twitch chat message, ignore it.
	if not data.IsChatMessage() or not data.IsFromTwitch():
		return

	# The command to try is the first parameter in the message, in lowercase.
	command = data.GetParam(0).lower()
	try:
		# If the first character is not a '!', or if we have an entry for it
		# in our settings but its value is False, stop here.
		if command[0] != '!' or Settings[command] != True:
			return
	except:
		# If locating the command in our settings failed, stop here.
		return

	# If we are using cooldown, perform management of it now.
	if Settings['cooldown'] > 0:
		# If the command is currently on cooldown, stop here.
		if Parent.IsOnCooldown(ScriptName, command):
			return
		# Otherwise, set it to be on cooldown now.
		Parent.AddCooldown(ScriptName, command, Settings['cooldown'])

	# Perform the command, and reply in Twitch chat with its results.
	Parent.SendTwitchMessage(PerformCommand(command))


def PerformCommand(command):
	# Join the path to the helper program, the specified command, and the name
	# of the broadcaster into a single command line command.
	helper = '%s %s %s' % (HelperCommand, command, Broadcaster)

	# We will attempt the command up to three times.
	for x in range(3):
		# Invoke the command, opening a file from which we can read its output.
		with os.popen(helper, 'r') as outputFile:
			# Read the command's output, stripping whitespace from either side.
			output = outputFile.read().strip()
			# If we did in fact obtain output, we're done.
			if output != "":
				return output

	# If the results of the command are empty, return an error.
	return 'An error occured processing the %s command.' % command

# Init()
# print Settings
# print PerformCommand('!build')
# print PerformCommand('!level')

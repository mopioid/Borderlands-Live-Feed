import os
import sys
import re

ScriptName = "Borderlands"
Website = "https://www.twitch.tv/mopioid"
Description = "Provides live BL2 & TPS data in response to !build & !level."
Creator = "mopioid"
Version = "1.0.0.0"


# The path to the directory containing this script and its resources.
ScriptDir = os.path.dirname(os.path.realpath(__file__))
# The path to the helper program within our directory, formatted for popen.
HelperCommand = '"' + os.path.join(ScriptDir, 'ChatbotHelper.exe') + '"'

def Init():
	# When Chatbot first loads us, store the display name for the broadcaster.
	global Broadcaster
	Broadcaster = Parent.GetDisplayName(Parent.GetChannelName())
	return

def Tick():
	return

def Execute(data):
	# If this is not a Twitch chat message, ignore it.
	if not data.IsChatMessage() or not data.IsFromTwitch():
		return
	# Otherwise, handle specific commands accordingly.
	elif data.GetParam(0).lower() == "!build":
		Parent.SendTwitchMessage(PerformCommand('build'))
	elif data.GetParam(0).lower() == "!level":
		Parent.SendTwitchMessage(PerformCommand('level'))

def PerformCommand(command):
	# Join the path to the helper program, the specified command, and the name
	# of the broadcaster into a single command line command.
	command = '%s %s %s' % (HelperCommand, command, Broadcaster)
	# We will be seeking for output until we find a non-empty string.
	output = ""
	# Invoke the command, opening the file from which we can read its output.
	with os.popen(command, 'r') as outputFile:
		# So long as no output has been found yet, attempt a read from the file. 
		while output == "":
			output = outputFile.readline()
	# Once output has been found, return it.
	return output

# Perform tests if we are being run outside of Chatbot.
try:
	Parent
except NameError:
	Broadcaster = 'mopioid'
	print PerformCommand("level")
	print PerformCommand("build")
